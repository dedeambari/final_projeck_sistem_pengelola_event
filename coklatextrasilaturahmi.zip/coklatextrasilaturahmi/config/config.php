<?php
// config.php

// Database settings
define('DB_HOST', 'localhost');
define('DB_NAME', 'event_system');
define('DB_USER', 'root');
define('DB_PASS', '');

// Email settings
define('EMAIL_HOST', 'smtp.mailtrap.io');
define('EMAIL_USER', 'your_email');
define('EMAIL_PASS', 'your_password');

// Other settings
define('BASE_URL', 'http://localhost/coklatextrasilaturahmi/');