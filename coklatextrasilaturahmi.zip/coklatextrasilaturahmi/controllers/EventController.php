<?php
// EventController.php
class EventController {
    public function listEvents() {
        // Logika untuk menampilkan daftar acara
    }
    public function createEvent() {
        // Logika untuk membuat acara baru
    }
}
