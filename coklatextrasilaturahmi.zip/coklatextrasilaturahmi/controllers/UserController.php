<?php
// UserController.php
class UserController {
    public function login() {
        // Logika untuk login pengguna
    }
    public function register() {
        // Logika untuk registrasi pengguna baru
    }
}
