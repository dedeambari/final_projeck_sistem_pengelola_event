<?php
// EventApiController.php
class EventApiController {
    public function getEvents() {
        // API untuk mengambil daftar acara
    }
}
