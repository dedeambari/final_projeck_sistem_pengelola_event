<?php include('includes/header.php'); ?>
<?php include('includes/navbar.php'); ?>

<div class="container">
    <h2>Upcoming Events</h2>
    <div class="event-card">
        <h3>Event Title</h3>
        <p>Description of the event.</p>
        <a href="event.php?id=1">View Details</a>
    </div>
</div>
<?php include('includes/footer.php'); ?>
