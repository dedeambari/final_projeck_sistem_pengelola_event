<?php
include('config/config.php');
?>

<nav>
    <ul>
        <li><a href="<?= BASE_URL ?>views/home.php">Home</a></li>
        <li><a href="<?= BASE_URL ?>views/profile.php">Events</a></li>
        <li><a href="<?= BASE_URL ?>views/login.php">Login</a></li>
        <li><a href="<?= BASE_URL ?>views/register.php">Register</a></li>
    </ul>
</nav>
