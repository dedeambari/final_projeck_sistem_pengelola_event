<footer>
    <p>&copy; 2024 Event System. All rights reserved.</p>
</footer>
