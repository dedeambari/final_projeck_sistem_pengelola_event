<?php
// Event.php
class Event {
    public $id;
    public $name;
    public $date;
    
    public function save() {
        // Logika untuk menyimpan data acara ke database
    }
    
    public static function getAll() {
        // Logika untuk mengambil semua acara dari database
    }
}
