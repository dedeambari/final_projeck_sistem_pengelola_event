<?php
// Ticket.php
class Ticket {
    public $id;
    public $event_id;
    public $user_id;
    
    public function save() {
        // Logika untuk menyimpan tiket yang dibeli
    }
}
