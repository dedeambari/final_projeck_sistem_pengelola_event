<?php
// index.php
include('views/home.php');
